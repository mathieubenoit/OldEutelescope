/*
   Copyright 2004-2010 IEAP CTU
   Author: Daniel Turecek (daniel.turecek@utef.cvut.cz)
*/

#ifndef PIXELMAN_VERSION

// Definition of pixelman version
#define PIXELMAN_VERSION "2.1.1"

#endif
